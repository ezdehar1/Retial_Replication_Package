#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
for seed in 43 44 45; do
  ddqn_details="results/rerun/ddqn/seed_${seed}/evaluation_details.csv"
  if [[ ! -f "$ddqn_details" ]]; then
    echo "Missing $ddqn_details. Run scripts/run_ddqn_seeds.sh first." >&2
    exit 1
  fi
  python3 code/DAGAME_GA_transition_aware_violation_current_relative_FR.py \
    --alpha 0.90 --beta 3.0 --seed "$seed" --pop 20 --gens 10 \
    --metrics inputs/Final_DS_JNN9_local_Desktop_UpdatedWed_all.csv \
    --configs inputs/ALL_Config_binary.csv \
    --evaluation inputs/JNN_evaluation_violation_only.csv \
    --rt-preprocessor models/JNN_RT_preproc_binary_rt95.pkl \
    --rt-model models/JNN_RT_XGB_binary_rt95.pkl \
    --ddqn-details "$ddqn_details" \
    --output-dir "results/rerun/ga/seed_${seed}"
done
