#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python3 scripts/aggregate_rq2_results.py \
  --ddqn-dir results/raw/ddqn \
  --ga-dir results/raw/ga \
  --output-dir results/recomputed
