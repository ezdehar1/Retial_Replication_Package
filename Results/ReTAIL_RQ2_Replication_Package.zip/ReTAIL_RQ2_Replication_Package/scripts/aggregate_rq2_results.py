#!/usr/bin/env python3
"""Recompute the RQ2 paper values from the included per-state logs."""
from __future__ import annotations

import argparse
from pathlib import Path
import numpy as np
import pandas as pd

SEEDS = (43, 44, 45)
METRICS = [
    "SLO recovery (%)",
    "Mean selected RT95 (ms)",
    "Mean reconfiguration distance d",
    "Mean functionality retention",
    "Oracle match (%)",
    "Median regret",
    "Minimum-distance recovery (%)",
]


def as_bool(series: pd.Series) -> pd.Series:
    if pd.api.types.is_bool_dtype(series):
        return series.fillna(False)
    if pd.api.types.is_numeric_dtype(series):
        return series.fillna(0).astype(float).ne(0)
    return series.astype(str).str.strip().str.lower().isin({"true", "1", "yes", "y"})


def percentage(series: pd.Series) -> float:
    if len(series) == 0:
        return float("nan")
    return float(as_bool(series).mean() * 100.0)


def ddqn_row(path: Path, seed: int) -> dict:
    df = pd.read_csv(path)
    successful = as_bool(df["agent_slo_compliant"])
    return {
        "Method": "ReTAIL",
        "Seed": seed,
        "States": len(df),
        "SLO recovery (%)": percentage(df["agent_slo_compliant"]),
        "Mean selected RT95 (ms)": float(df["agent_rt95_ms"].mean()),
        "Mean reconfiguration distance d": float(df["agent_distance"].mean()),
        "Mean functionality retention": float(df["agent_fr"].mean()),
        "Oracle match (%)": percentage(df["match"]),
        "Median regret": float(df["regret"].median()),
        "Minimum-distance recovery (%)": percentage(
            df.loc[successful, "agent_minimum_distance_recovery"]
        ),
    }


def ga_row(path: Path, seed: int) -> dict:
    df = pd.read_csv(path)
    successful = as_bool(df["ga_slo_compliant"])
    return {
        "Method": "DAGAME-GA",
        "Seed": seed,
        "States": len(df),
        "SLO recovery (%)": percentage(df["ga_slo_compliant"]),
        "Mean selected RT95 (ms)": float(df["ga_rt95_ms"].mean()),
        "Mean reconfiguration distance d": float(df["ga_distance"].mean()),
        "Mean functionality retention": float(df["ga_fr"].mean()),
        "Oracle match (%)": percentage(df["ga_oracle_match"]),
        "Median regret": float(df["ga_regret"].median()),
        "Minimum-distance recovery (%)": percentage(
            df.loc[successful, "ga_minimum_distance_recovery"]
        ),
    }


def oracle_row(path: Path) -> dict:
    df = pd.read_csv(path)
    return {
        "Method": "Oracle",
        "Seeds": "deterministic",
        "SLO recovery (%) mean": percentage(df["oracle_slo_compliant"]),
        "SLO recovery (%) SD": np.nan,
        "Mean selected RT95 (ms) mean": float(df["oracle_rt95_ms"].mean()),
        "Mean selected RT95 (ms) SD": np.nan,
        "Mean reconfiguration distance d mean": float(df["oracle_distance"].mean()),
        "Mean reconfiguration distance d SD": np.nan,
        "Mean functionality retention mean": float(df["oracle_fr"].mean()),
        "Mean functionality retention SD": np.nan,
        "Oracle match (%) mean": 100.0,
        "Oracle match (%) SD": np.nan,
        "Median regret mean": 0.0,
        "Median regret SD": np.nan,
        "Minimum-distance recovery (%) mean": 100.0,
        "Minimum-distance recovery (%) SD": np.nan,
    }


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--ddqn-dir", default="results/raw/ddqn")
    p.add_argument("--ga-dir", default="results/raw/ga")
    p.add_argument("--output-dir", default="results/recomputed")
    args = p.parse_args()

    ddqn_dir = Path(args.ddqn_dir)
    ga_dir = Path(args.ga_dir)
    out = Path(args.output_dir)
    out.mkdir(parents=True, exist_ok=True)

    rows = []
    for seed in SEEDS:
        rows.append(ddqn_row(ddqn_dir / f"seed_{seed}" / "evaluation_details.csv", seed))
        rows.append(ga_row(ga_dir / f"seed_{seed}" / "evaluation_details.csv", seed))
    seed_df = pd.DataFrame(rows).sort_values(["Method", "Seed"]).reset_index(drop=True)
    seed_df.to_csv(out / "RQ2_seed_level_results.csv", index=False)

    aggregate_rows = []
    for method in ("ReTAIL", "DAGAME-GA"):
        subset = seed_df[seed_df["Method"] == method]
        row = {"Method": method, "Seeds": "43,44,45"}
        for metric in METRICS:
            row[f"{metric} mean"] = float(subset[metric].mean())
            row[f"{metric} SD"] = float(subset[metric].std(ddof=1))
        aggregate_rows.append(row)

    oracle_details = pd.read_csv(ga_dir / "seed_43" / "evaluation_details.csv")
    aggregate_rows.append(oracle_row(ga_dir / "seed_43" / "evaluation_details.csv"))
    aggregate_df = pd.DataFrame(aggregate_rows)
    aggregate_df.to_csv(out / "RQ2_aggregate_mean_sd_with_oracle.csv", index=False)

    # Compact values matching the two panels reported in the paper.
    paper_rows = []
    for _, row in aggregate_df.iterrows():
        paper_rows.append({
            "Method": row["Method"],
            "Recovery_mean": row["SLO recovery (%) mean"],
            "Recovery_SD": row["SLO recovery (%) SD"],
            "RT95_mean_ms": row["Mean selected RT95 (ms) mean"],
            "RT95_SD_ms": row["Mean selected RT95 (ms) SD"],
            "d_mean": row["Mean reconfiguration distance d mean"],
            "d_SD": row["Mean reconfiguration distance d SD"],
            "FR_mean": row["Mean functionality retention mean"],
            "FR_SD": row["Mean functionality retention SD"],
            "Oracle_match_mean": row["Oracle match (%) mean"],
            "Oracle_match_SD": row["Oracle match (%) SD"],
            "Median_regret_mean": row["Median regret mean"],
            "Median_regret_SD": row["Median regret SD"],
            "Min_distance_recovery_mean": row["Minimum-distance recovery (%) mean"],
            "Min_distance_recovery_SD": row["Minimum-distance recovery (%) SD"],
        })
    pd.DataFrame(paper_rows).to_csv(out / "RQ2_paper_table_values.csv", index=False)
    print(aggregate_df.to_string(index=False))


if __name__ == "__main__":
    main()
