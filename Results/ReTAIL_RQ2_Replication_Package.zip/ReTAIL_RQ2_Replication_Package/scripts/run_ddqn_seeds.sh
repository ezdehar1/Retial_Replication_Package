#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
for seed in 43 44 45; do
  python3 code/DDQN_Conf_violation_only_FR_current_relative.py \
    --alpha 0.90 --beta 3.0 --seed "$seed" --steps 120000 \
    --metrics inputs/Final_DS_JNN9_local_Desktop_UpdatedWed_all.csv \
    --configs inputs/ALL_Config_binary.csv \
    --startup inputs/JNN_startup_violation_only.csv \
    --evaluation inputs/JNN_evaluation_violation_only.csv \
    --rt-preprocessor models/JNN_RT_preproc_binary_rt95.pkl \
    --rt-model models/JNN_RT_XGB_binary_rt95.pkl \
    --output-dir "results/rerun/ddqn/seed_${seed}"
done
