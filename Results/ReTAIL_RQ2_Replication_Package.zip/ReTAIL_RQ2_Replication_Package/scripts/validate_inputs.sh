#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python3 code/DDQN_Conf_violation_only_FR_current_relative.py \
  --metrics inputs/Final_DS_JNN9_local_Desktop_UpdatedWed_all.csv \
  --configs inputs/ALL_Config_binary.csv \
  --startup inputs/JNN_startup_violation_only.csv \
  --evaluation inputs/JNN_evaluation_violation_only.csv \
  --validate-only
python3 code/DAGAME_GA_transition_aware_violation_current_relative_FR.py \
  --metrics inputs/Final_DS_JNN9_local_Desktop_UpdatedWed_all.csv \
  --configs inputs/ALL_Config_binary.csv \
  --evaluation inputs/JNN_evaluation_violation_only.csv \
  --validate-only
