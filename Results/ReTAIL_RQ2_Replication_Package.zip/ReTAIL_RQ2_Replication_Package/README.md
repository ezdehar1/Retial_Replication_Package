# ReTAIL RQ2 Replication Package

## Scope

This compact package supports RQ2: the offline decision quality of ReTAIL
compared with DAGAME-GA, using an exhaustive oracle as the optimal reference.
It contains the common 70-state violation-only evaluation dataset, the complete
204-configuration JNN adaptation space, the RT95 prediction artifacts, exact
experiment code, and per-state outputs for seeds 43, 44, and 45.

The archived experiment settings are:

- ReTAIL: `alpha = 0.90`, `beta = 3.0`, 120,000 DDQN training steps.
- DAGAME-GA: `alpha = 0.90`, `beta = 3.0`, population 20, 10 generations.
- Exhaustive oracle: all 204 valid configurations evaluated per state.
- SLO threshold: 66.9 ms.
- Functional retention: current-relative optional-functionality retention.

Decision latency is intentionally excluded from RQ2, matching the paper.

## Quick reproduction of the paper table

The fast path recomputes all RQ2 metrics from the included per-state logs:

```bash
cd ReTAIL_RQ2_Replication_Package
python3 -m venv .venv
source .venv/bin/activate
pip install pandas numpy
bash scripts/reproduce_rq2_table.sh
```

The main outputs are:

- `results/recomputed/RQ2_seed_level_results.csv`
- `results/recomputed/RQ2_aggregate_mean_sd_with_oracle.csv`
- `results/recomputed/RQ2_paper_table_values.csv`

The aggregation uses the sample standard deviation (`ddof=1`) across seeds.

## Full rerun

Install the complete requirements, validate the inputs, rerun DDQN, then rerun
DAGAME-GA and aggregate the new results:

```bash
pip install -r requirements.txt
bash scripts/validate_inputs.sh
bash scripts/run_ddqn_seeds.sh
bash scripts/run_ga_seeds.sh
python3 scripts/aggregate_rq2_results.py   --ddqn-dir results/rerun/ddqn   --ga-dir results/rerun/ga   --output-dir results/rerun/aggregate
```

The full rerun is computationally longer and learned-policy results may vary
slightly across software or hardware environments. The included archived logs
are the canonical outputs used for the paper.

## Directory structure

- `code/`: exact DDQN and DAGAME-GA experiment scripts.
- `inputs/`: metrics, startup/evaluation data, and valid configurations.
- `models/`: serialized RT95 prediction model and preprocessor.
- `results/raw/ddqn/`: ReTAIL outputs and trained policies for three seeds.
- `results/raw/ga/`: DAGAME-GA per-state outputs for three seeds.
- `results/raw/oracle/`: deterministic oracle decision for every state.
- `results/processed/`: original aggregate files used during analysis.
- `scripts/`: validation, rerun, and aggregation commands.
- `paper/`: RQ2 table and concise result text.
- `docs/`: data and paper-result mapping.

## Anonymity and licensing

The package was scanned for author names, institutional names, email addresses,
and common absolute local paths. No such identifiers were found in readable
files. No open-source license has been selected; add the authors' chosen license
before a permanent public release.

## Environment note

Exact package versions were not recorded in the archived run logs. The listed
requirements therefore name the required libraries without pinning versions.
Serialized XGBoost/scikit-learn artifacts may require a compatible environment.
