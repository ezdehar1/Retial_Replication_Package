# Data description

- `Final_DS_JNN9_local_Desktop_UpdatedWed_all.csv`: performance-characterization measurements used by the experiment code.
- `ALL_Config_binary.csv`: all 204 valid JNN configurations encoded by 11 concrete feature flags.
- `JNN_startup_violation_only.csv`: violation-only startup states used during DDQN learning.
- `JNN_evaluation_violation_only.csv`: fixed 70-state violation-only evaluation dataset used by ReTAIL, DAGAME-GA, and the exhaustive oracle.

The evaluation rows are shared across all methods. The SLO threshold is 66.9 ms.
