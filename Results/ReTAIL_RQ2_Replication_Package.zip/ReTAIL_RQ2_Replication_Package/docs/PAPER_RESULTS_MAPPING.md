# Paper-results mapping

## RQ2 / Table 4

- ReTAIL per-state outputs: `results/raw/ddqn/seed_*/evaluation_details.csv`
- DAGAME-GA per-state outputs: `results/raw/ga/seed_*/evaluation_details.csv`
- Exhaustive oracle decisions: `results/raw/oracle/oracle_reference_per_state.csv`
- Canonical aggregate: `results/processed/RQ2_aggregate_mean_sd.csv`
- Recomputed paper values: `results/recomputed/RQ2_paper_table_values.csv`
- Publication table: `paper/RQ2_table.tex`

Reproduction command:

```bash
bash scripts/reproduce_rq2_table.sh
```
