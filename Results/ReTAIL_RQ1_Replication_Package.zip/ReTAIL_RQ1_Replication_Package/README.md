# ReTAIL RQ1 Replication Package

## Scope

This package supports RQ1: the value and sensitivity of reconfiguration-aware
DDQN reasoning. It contains the complete results for five values of the
reconfiguration-awareness weight (`alpha = 0.00, 0.25, 0.50, 0.75, 0.90`)
and three independent seeds (`43, 44, 45`). Every run used `beta = 3.0`,
`120000` training steps, the same startup and evaluation datasets, and the
same 204-action JNN configuration space.

## Main reported result

Across the endpoint settings, increasing alpha from 0.00 to 0.90 reduced mean
normalized transition distance from 0.5251 to
0.1009 (80.8% reduction) and increased mean FR from
0.1706 to 0.7523, while predicted SLO recovery
remained near complete.

## Directory structure

- `code/`: DDQN experiment implementation.
- `inputs/`: metrics, configuration, startup, and evaluation datasets.
- `models/`: XGBoost RT95 model and preprocessing object.
- `results/raw_runs/`: canonical outputs for all 15 alpha/seed runs.
- `results/processed/`: seed-level and mean±SD aggregate results.
- `paper/`: publication-ready LaTeX table and RQ1 result text.
- `scripts/run_all_rq1.sh`: reruns all 15 experiments on macOS/Linux.
- `scripts/aggregate_rq1_results.py`: rebuilds the aggregate CSV files.
- `provenance/`: source-archive checksums and correction provenance.

## Reproducing the experiments on macOS

```bash
cd ReTAIL_RQ1_Replication_Package
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
bash scripts/run_all_rq1.sh
```

To aggregate an existing set of run directories without retraining:

```bash
python3 scripts/aggregate_rq1_results.py \
  --runs-dir results/raw_runs \
  --output-dir results/recomputed
```

The aggregation uses the sample standard deviation (`ddof=1`) across the three
seeds.

## Functional-retention definition

FR is the number of optional abstract functionalities retained in the selected
configuration divided by the number enabled in the currently deployed
configuration. If the current configuration enables no optional functionality,
FR is defined as 1.0. The five optional groups are Media, Analytics,
Recommendation, Breaking, and Advertisement.

The canonical Seed-45 evaluation files in this package use this current-relative
FR definition. For alpha values 0.25, 0.50, 0.75, and 0.90, corrected evaluation
metadata replaced earlier fixed-denominator FR metadata; training traces and
learned models were unchanged.

## Key files

- `results/processed/RQ1_alpha_sensitivity_mean_sd.csv`: final table values.
- `results/processed/RQ1_seed_level_results.csv`: individual seed results.
- `paper/RQ1_table.tex`: LaTeX table for the paper.
- `paper/RQ1_results_text.tex`: concise RQ1 analysis.
- `SHA256SUMS.txt`: package file-integrity checksums.
