#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$ROOT/results/reproduced_runs"
mkdir -p "$OUT"

for alpha in 0.00 0.25 0.50 0.75 0.90; do
  for seed in 43 44 45; do
    echo "Running alpha=${alpha}, seed=${seed}"
    python3 "$ROOT/code/DDQN_Conf_violation_only_FR_current_relative.py" \
      --alpha "$alpha" \
      --beta 3.0 \
      --seed "$seed" \
      --steps 120000 \
      --metrics "$ROOT/inputs/Final_DS_JNN9_local_Desktop_UpdatedWed_all.csv" \
      --configs "$ROOT/inputs/ALL_Config_binary.csv" \
      --startup "$ROOT/inputs/JNN_startup_violation_only.csv" \
      --evaluation "$ROOT/inputs/JNN_evaluation_violation_only.csv" \
      --rt-preprocessor "$ROOT/models/JNN_RT_preproc_binary_rt95.pkl" \
      --rt-model "$ROOT/models/JNN_RT_XGB_binary_rt95.pkl" \
      --output-dir "$OUT/alpha_${alpha}_seed_${seed}"
  done
done

python3 "$ROOT/scripts/aggregate_rq1_results.py" \
  --runs-dir "$OUT" \
  --output-dir "$ROOT/results/reproduced_processed"
