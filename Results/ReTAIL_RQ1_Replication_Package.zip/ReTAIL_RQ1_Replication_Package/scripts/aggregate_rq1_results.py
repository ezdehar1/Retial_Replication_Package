#!/usr/bin/env python3
from __future__ import annotations

import argparse
import re
from pathlib import Path
import pandas as pd

METRICS = {
    "recovery_pct": "agent_slo_compliance_pct",
    "mean_selected_rt95_ms": "mean_agent_rt95_ms",
    "mean_transition_distance": "mean_agent_distance",
    "mean_functionality_retention": "mean_agent_fr",
    "mean_changed_flags": "mean_agent_changed_flags",
    "oracle_match_pct": "oracle_match_pct",
    "median_regret": "median_regret",
    "minimum_distance_recovery_pct": "minimum_distance_recovery_pct",
}

def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--runs-dir", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)

    rows = []
    for run_dir in sorted(args.runs_dir.iterdir()):
        match = re.fullmatch(r"alpha_(\d+\.\d+)_seed_(\d+)", run_dir.name)
        if not match:
            continue
        summary = run_dir / "evaluation_summary.csv"
        if not summary.exists():
            raise FileNotFoundError(summary)
        raw = pd.read_csv(summary).iloc[0]
        row = {
            "alpha": float(match.group(1)),
            "seed": int(match.group(2)),
            "states": int(raw["states"]),
        }
        for out_name, source_name in METRICS.items():
            row[out_name] = raw[source_name]
        rows.append(row)

    seed_df = pd.DataFrame(rows).sort_values(["alpha", "seed"])
    seed_df.to_csv(args.output_dir / "RQ1_seed_level_results.csv", index=False, float_format="%.12g")

    aggregate_rows = []
    for alpha, group in seed_df.groupby("alpha", sort=True):
        row = {"alpha": alpha, "seeds": "43,44,45", "n_seeds": len(group)}
        for metric in METRICS:
            row[f"{metric}_mean"] = group[metric].mean()
            row[f"{metric}_sd"] = group[metric].std(ddof=1)
        aggregate_rows.append(row)
    pd.DataFrame(aggregate_rows).to_csv(
        args.output_dir / "RQ1_alpha_sensitivity_mean_sd.csv", index=False, float_format="%.12g"
    )

if __name__ == "__main__":
    main()
