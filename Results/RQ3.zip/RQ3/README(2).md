# RQ3 Final Adopted Online Results

## Experimental protocol
- System: JNN
- Initial configuration: Config 184
- Workload duration: 30 minutes
- Repetitions: 3 runs per method
- Methods:
  1. Latency-only DDQN (alpha = 0)
  2. ReTAIL / transition-aware DDQN (alpha = 0.90)
  3. Transition-aware DAGAME-GA
- All methods achieved 100% recovery from triggered adaptation episodes.

## Aggregate results (mean ± SD)

| Method | Violation rate (%) | Mean measured RT95 (ms) | Adaptations | Mean transition distance | Functionality retention | E2E adaptation time (s) |
|---|---:|---:|---:|---:|---:|---:|
| Latency-only DDQN | 6.67 ± 0.00 | 14.58 ± 2.38 | 1.00 ± 0.00 | 0.5758 ± 0.0525 | 0.1333 ± 0.1155 | 101.82 ± 0.03 |
| ReTAIL (alpha = 0.90) | 6.67 ± 0.00 | 51.73 ± 0.48 | 1.00 ± 0.00 | 0.0909 ± 0.0000 | 0.8000 ± 0.0000 | 101.21 ± 0.06 |
| DAGAME-GA | 18.89 ± 1.92 | 52.36 ± 0.76 | 2.00 ± 0.00 | 0.1364 ± 0.0000 | 0.6500 ± 0.0000 | 101.37 ± 0.05 |

## Adopted interpretation
- Latency-only DDQN selected Config 103 in two runs and Config 1 in one run.
- ReTAIL selected Config 160 in all three runs.
- ReTAIL changed only one of eleven concrete feature flags:
  d = 1/11 = 0.0909.
- ReTAIL retained 80% of the optional functionality enabled before adaptation.
- Relative to latency-only DDQN, ReTAIL reduced mean transition distance by approximately 84.2%, while preserving the same violation rate and 100% recovery.
- DAGAME-GA first selected Config 182, remained near the SLO boundary, and later required a second transition to Config 38.
- Relative to GA, ReTAIL reduced violation rate by approximately 64.7%, required one instead of two adaptations, and achieved lower transition distance and higher functionality retention.
- E2E adaptation time should be reported in prose rather than as a main table column because values are nearly identical and dominated by the fixed reconfiguration warm-up and the next complete monitoring interval.
- Main RQ3 table should include:
  violation rate, mean measured RT95, number of adaptations, transition distance, and functionality retention.

## Final result statement
ReTAIL matched the complete recovery and low violation rate of latency-only DDQN while substantially reducing architectural disruption and retaining more existing functionality. Compared with transition-aware GA, ReTAIL experienced fewer violations, required half as many adaptations, and preserved more of the deployed architecture.
