#!/usr/bin/env python3
"""
Unified online controller for RQ3 of the transition-aware JNN study.

Online modes
------------
- ddqn09 : transition-aware DDQN, alpha=0.90, offline-selected Seed 44
- ddqn0  : latency-only DDQN, alpha=0.00, offline-selected Seed 45
- ga     : transition-aware DAGAME-GA, alpha=0.90, fixed base Seed 45
- rule   : fixed safe-configuration rule (Config 1)
- static : no runtime adaptation

Example
-------
python JNN_RQ3_online_controller.py --mode ddqn09 --start-config 39 --runs 3

Only three command-line arguments are used. All paths and experiment settings are
kept in the clearly marked SETTINGS section below.
"""

from __future__ import annotations

import argparse
import hashlib
import csv
import json
import logging
import os
import random
import shutil
import subprocess
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from statistics import mean, median
from time import perf_counter
from typing import Any, Dict, List, Mapping, Optional, Sequence, Set, Tuple

import joblib
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F


# =============================================================================
# SETTINGS: edit these paths/settings once for the online environment
# =============================================================================

# Input data and models
TRACE_CSV = Path("Data/trace3_4.csv")                    # columns: minute, rpm, optional phase
SERVICE_CONFIG_CSV = Path("Data/Configs2.csv")          # Config_ID, Active_Services
BINARY_CONFIG_CSV = Path("Data/DataConf/ALL_Config_binary.csv")
METRICS_CSV = Path("Data/DataConf/Final_DS_JNN9_local_Desktop_UpdatedWed_all.csv")
RT_PREPROCESSOR_PATH = Path("PM_Models_Conf/Models/JNN_RT_preproc_binary_rt95.pkl")
RT_MODEL_PATH = Path("PM_Models_Conf/Models/JNN_RT_XGB_binary_rt95.pkl")
DDQN09_MODEL_PATH = Path("Online_Models/DDQN_alpha_0.90_seed_44/ddqn_model.pt")
DDQN0_MODEL_PATH = Path("Online_Models/DDQN_alpha_0.00_seed_45/ddqn_model.pt")
DDQN09_MODEL_SHA256 = "8e7cd45b6055a036b1bff168819e36da952e9f0716ab4e23a64f71c12752c5a2"
DDQN0_MODEL_SHA256 = "68ec11be24aac93cdfe7dc45374982fee12be36c3cad3d9f17b2f720a5a9082d"

# Output
OUTPUT_ROOT = Path("Online_RQ3")

# Runtime/k6/Kubernetes
K6_POD = "k6-runner"
K6_SCRIPT_IN_POD = "/scripts/jnn_k6_online.js"
K6_OUTPUT_DIR_IN_POD = "/tmp/out"
BASE_URL = "http://gateway:8888"
NAMESPACE = ""  # empty means the current/default namespace
PRE_VUS = 50
MAX_VUS = 500
ALWAYS_ON: Set[str] = {"gateway"}

# Shared experiment settings
TAU_MS = 66.9
SAFE_CONFIG = 1
VIOLATION_PERSISTENCE = 2
COOLDOWN_MINUTES = 3
RECONFIGURATION_WARMUP_SECONDS = 40
BETWEEN_RUNS_WAIT_SECONDS = 120

# Fixed GA settings. The same seed sequence restarts in every runtime repetition.
GA_ALPHA = 0.90
GA_BETA = 3.0
GA_POPULATION = 20
GA_GENERATIONS = 10
GA_CROSSOVER_PROBABILITY = 1.0
GA_MUTATION_PROBABILITY = 1.0
GA_BASE_SEED = 30

# JNN feature model
FLAG_COLS: Tuple[str, ...] = (
    "adv1",
    "adv2",
    "analytics1",
    "analytics2",
    "breaking",
    "content1",
    "content2",
    "media1",
    "media2",
    "recommendation1",
    "recommendation2",
)

OPTIONAL_FEATURE_GROUPS: Mapping[str, Tuple[str, ...]] = {
    "media": ("media1", "media2"),
    "analytics": ("analytics1", "analytics2"),
    "recommendation": ("recommendation1", "recommendation2"),
    "breaking": ("breaking",),
    "advertisement": ("adv1", "adv2"),
}

MODE_ALIASES = {
    "ddqn09": "ddqn09",
    "ddqn.9": "ddqn09",
    "ddqn0.9": "ddqn09",
    "ddqn0": "ddqn0",
    "ddqn.0": "ddqn0",
    "ga": "ga",
    "rule": "rule",
    "static": "static",
}


# =============================================================================
# General helpers
# =============================================================================


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds")


def json_safe(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(k): json_safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [json_safe(v) for v in value]
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating,)):
        return None if np.isnan(value) else float(value)
    if isinstance(value, (np.bool_,)):
        return bool(value)
    if isinstance(value, float) and np.isnan(value):
        return None
    return value


def write_json(path: Path, payload: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(json_safe(payload), handle, indent=2)


def safe_mean(values: Sequence[float]) -> Optional[float]:
    clean = [float(v) for v in values if v is not None and np.isfinite(float(v))]
    return float(mean(clean)) if clean else None


def safe_median(values: Sequence[float]) -> Optional[float]:
    clean = [float(v) for v in values if v is not None and np.isfinite(float(v))]
    return float(median(clean)) if clean else None


def safe_p95(values: Sequence[float]) -> Optional[float]:
    clean = [float(v) for v in values if v is not None and np.isfinite(float(v))]
    return float(np.quantile(clean, 0.95)) if clean else None


def min_max_scale(value: float, lower: float, upper: float) -> float:
    if upper <= lower:
        return 0.0
    return float(np.clip((float(value) - lower) / (upper - lower), 0.0, 1.0))


def stable_rt_normalization(rt: float, mean_value: float, std_value: float, eps: float = 1e-8) -> float:
    z_score = (float(rt) - float(mean_value)) / (float(std_value) + eps)
    return float((np.tanh(z_score) + 1.0) / 2.0)


def validate_required_paths(mode: str) -> None:
    required = [TRACE_CSV, SERVICE_CONFIG_CSV, BINARY_CONFIG_CSV, METRICS_CSV]
    if mode == "ddqn09":
        required.append(DDQN09_MODEL_PATH)
    elif mode == "ddqn0":
        required.append(DDQN0_MODEL_PATH)
    elif mode == "ga":
        required.extend([RT_PREPROCESSOR_PATH, RT_MODEL_PATH])

    missing = [str(path) for path in required if not path.exists()]
    if missing:
        raise FileNotFoundError(
            "Required online experiment files were not found:\n- " + "\n- ".join(missing)
        )


# =============================================================================
# Configuration representation, distance, and current-relative FR
# =============================================================================


class ConfigurationSpace:
    def __init__(self, binary_config_csv: Path) -> None:
        frame = pd.read_csv(binary_config_csv)
        required = ["Config_ID", *FLAG_COLS]
        missing = [column for column in required if column not in frame.columns]
        if missing:
            raise ValueError(f"Binary configuration CSV is missing columns: {missing}")

        table = (
            frame[required]
            .drop_duplicates(subset="Config_ID")
            .copy()
            .sort_values("Config_ID")
            .reset_index(drop=True)
        )
        table["Config_ID"] = table["Config_ID"].astype(int)
        for column in FLAG_COLS:
            table[column] = table[column].astype(int)
            values = set(table[column].unique().tolist())
            if not values.issubset({0, 1}):
                raise ValueError(f"Configuration flag {column!r} is not binary: {sorted(values)}")

        self.table = table
        self.action_ids: List[int] = table["Config_ID"].astype(int).tolist()
        self.flags_by_id: Dict[int, np.ndarray] = {
            int(row["Config_ID"]): row[list(FLAG_COLS)].to_numpy(dtype=np.float32)
            for _, row in table.iterrows()
        }
        self.max_distance = float(len(FLAG_COLS))

    def validate_id(self, config_id: int) -> None:
        if int(config_id) not in self.flags_by_id:
            raise ValueError(f"Unknown Config_ID: {config_id}")

    def flags_for(self, config_id: int) -> np.ndarray:
        self.validate_id(config_id)
        return self.flags_by_id[int(config_id)].copy()

    def changed_flags(self, current_config: int, selected_config: int) -> int:
        return int(np.count_nonzero(self.flags_for(current_config) != self.flags_for(selected_config)))

    def normalized_distance(self, current_config: int, selected_config: int) -> float:
        return float(self.changed_flags(current_config, selected_config) / self.max_distance)

    def optional_presence(self, config_id: int) -> Dict[str, bool]:
        vector = self.flags_for(config_id)
        values = {name: bool(vector[index]) for index, name in enumerate(FLAG_COLS)}
        return {
            feature: any(values[variant] for variant in variants)
            for feature, variants in OPTIONAL_FEATURE_GROUPS.items()
        }

    def functional_retention(
        self,
        current_config: int,
        selected_config: int,
    ) -> Tuple[float, int, int, int]:
        current = self.optional_presence(current_config)
        selected = self.optional_presence(selected_config)
        retained = sum(int(current[name] and selected[name]) for name in current)
        current_enabled = sum(int(value) for value in current.values())
        selected_enabled = sum(int(value) for value in selected.values())
        fr = 1.0 if current_enabled == 0 else float(retained / current_enabled)
        return float(fr), int(retained), int(current_enabled), int(selected_enabled)


# =============================================================================
# DDQN online inference
# =============================================================================


class DuelingQFunction(nn.Module):
    """Inference-only dueling network compatible with the saved DDQN checkpoint."""

    def __init__(self, observation_size: int, number_of_actions: int, hidden_size: int) -> None:
        super().__init__()
        self.fc1 = nn.Linear(observation_size, hidden_size)
        self.fc2 = nn.Linear(hidden_size, hidden_size)
        self.fc_advantage = nn.Linear(hidden_size, number_of_actions)
        self.fc_value = nn.Linear(hidden_size, 1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if x.ndim == 1:
            x = x.unsqueeze(0)
        hidden = F.relu(self.fc1(x))
        hidden = F.relu(self.fc2(hidden))
        advantages = self.fc_advantage(hidden)
        values = self.fc_value(hidden)
        return values + (advantages - advantages.mean(dim=1, keepdim=True))


class DDQNPolicy:
    def __init__(
        self,
        checkpoint_path: Path,
        expected_alpha: float,
        expected_seed: int,
        expected_sha256: str,
        config_space: ConfigurationSpace,
        metrics_df: pd.DataFrame,
    ) -> None:
        actual_sha256 = hashlib.sha256(checkpoint_path.read_bytes()).hexdigest()
        if actual_sha256 != expected_sha256:
            raise ValueError(
                f"Unexpected DDQN checkpoint file at {checkpoint_path}. "
                f"Expected SHA256 {expected_sha256}, found {actual_sha256}. "
                "Use the frozen violation-only model selected for RQ3."
            )
        try:
            checkpoint = torch.load(checkpoint_path, map_location="cpu", weights_only=False)
        except TypeError:  # compatibility with older PyTorch
            checkpoint = torch.load(checkpoint_path, map_location="cpu")

        required_keys = {
            "model_state_dict",
            "observation_size",
            "number_of_actions",
            "flag_columns",
            "alpha",
            "beta",
            "tau_ms",
            "seed",
        }
        missing = sorted(required_keys.difference(checkpoint.keys()))
        if missing:
            raise ValueError(f"DDQN checkpoint is missing keys: {missing}")

        observation_size = int(checkpoint["observation_size"])
        number_of_actions = int(checkpoint["number_of_actions"])
        checkpoint_flags = tuple(checkpoint["flag_columns"])
        checkpoint_alpha = float(checkpoint["alpha"])
        checkpoint_seed = int(checkpoint["seed"])

        if observation_size != 2 + len(FLAG_COLS):
            raise ValueError(f"Expected DDQN observation size 13, found {observation_size}.")
        if number_of_actions != len(config_space.action_ids):
            raise ValueError(
                f"Checkpoint has {number_of_actions} actions but configuration CSV has "
                f"{len(config_space.action_ids)} configurations."
            )
        if checkpoint_flags != FLAG_COLS:
            raise ValueError(
                f"Checkpoint flag order {checkpoint_flags} does not match expected {FLAG_COLS}."
            )
        if not np.isclose(checkpoint_alpha, expected_alpha):
            raise ValueError(
                f"Wrong DDQN model: expected alpha={expected_alpha}, checkpoint has {checkpoint_alpha}."
            )
        if checkpoint_seed != expected_seed:
            raise ValueError(
                f"Wrong DDQN model: expected Seed {expected_seed}, checkpoint has Seed {checkpoint_seed}."
            )
        if not np.isclose(float(checkpoint["tau_ms"]), TAU_MS):
            logging.warning(
                "Checkpoint tau %.4f differs from online tau %.4f.",
                float(checkpoint["tau_ms"]),
                TAU_MS,
            )

        state_dict = checkpoint["model_state_dict"]
        hidden_size = int(state_dict["fc1.weight"].shape[0])
        self.network = DuelingQFunction(observation_size, number_of_actions, hidden_size)
        self.network.load_state_dict(state_dict)
        self.network.eval()

        self.action_ids = list(config_space.action_ids)
        self.config_space = config_space
        self.rpm_min = float(metrics_df["actual_rpm"].astype(float).min())
        self.rpm_max = float(metrics_df["actual_rpm"].astype(float).max())
        self.rt_mean = float(metrics_df["rt_95"].astype(float).mean())
        self.rt_std = float(metrics_df["rt_95"].astype(float).std(ddof=1))
        self.alpha = checkpoint_alpha
        self.seed = checkpoint_seed

    def encode_state(self, rpm: float, observed_rt95: float, current_config: int) -> np.ndarray:
        normalized_rpm = min_max_scale(rpm, self.rpm_min, self.rpm_max)
        normalized_rt = stable_rt_normalization(observed_rt95, self.rt_mean, self.rt_std)
        current_flags = self.config_space.flags_for(current_config).astype(np.float32)
        return np.concatenate(
            (np.asarray([normalized_rpm, normalized_rt], dtype=np.float32), current_flags)
        ).astype(np.float32)

    def choose_config(self, current_config: int, observed_rt95: float, rpm: float) -> Tuple[int, float, Dict[str, Any]]:
        started = perf_counter()
        observation = self.encode_state(rpm, observed_rt95, current_config)
        input_tensor = torch.tensor(observation, dtype=torch.float32).unsqueeze(0)
        with torch.inference_mode():
            q_values = self.network(input_tensor)
            action_index = int(torch.argmax(q_values, dim=1).item())
        selected_config = int(self.action_ids[action_index])
        decision_time_ms = float((perf_counter() - started) * 1000.0)
        return selected_config, decision_time_ms, {
            "action_index": action_index,
            "policy_alpha": self.alpha,
            "policy_seed": self.seed,
        }


# =============================================================================
# Minimal online DAGAME-GA implementation, aligned with the offline baseline
# =============================================================================


@dataclass(frozen=True)
class CandidateEvaluation:
    config_id: int
    reward: float
    predicted_rt95_ms: float
    normalized_rt: float
    distance: float
    changed_flags: int
    slo_compliant: bool

    @property
    def rank_key(self) -> Tuple[float, float, float, int]:
        return (
            float(self.reward),
            -float(self.distance),
            -float(self.predicted_rt95_ms),
            -int(self.config_id),
        )


@dataclass
class GASearchResult:
    selected: CandidateEvaluation
    decision_time_ms: float
    unique_evaluated_configs: int
    mean_repair_hamming: float
    maximum_repair_hamming: int


class TransitionAwareGAProblem:
    def __init__(
        self,
        metrics_df: pd.DataFrame,
        config_space: ConfigurationSpace,
        rt_preprocessor: Any,
        rt_model: Any,
    ) -> None:
        self.alpha = GA_ALPHA
        self.beta = GA_BETA
        self.tau_ms = TAU_MS
        self.rt_preprocessor = rt_preprocessor
        self.rt_model = rt_model
        self.config_space = config_space

        self.valid_x = config_space.table[list(FLAG_COLS)].to_numpy(dtype=int)
        self.config_ids = config_space.table["Config_ID"].to_numpy(dtype=int)
        self.n_genes = len(FLAG_COLS)
        self.id_to_index = {
            int(config_id): int(index) for index, config_id in enumerate(self.config_ids)
        }
        self.tuple_to_index: Dict[Tuple[int, ...], int] = {}
        for index, vector in enumerate(self.valid_x):
            self.tuple_to_index.setdefault(tuple(vector.tolist()), int(index))

        self.rt_mean = float(metrics_df["rt_95"].astype(float).mean())
        self.rt_std = float(metrics_df["rt_95"].astype(float).std(ddof=1))

    def normalized_rt(self, rt95_ms: float) -> float:
        return stable_rt_normalization(rt95_ms, self.rt_mean, self.rt_std)

    def predict_rt(self, config_id: int, rpm: float) -> float:
        vector = self.config_space.flags_for(config_id)
        feature_row = {
            column: float(vector[index]) for index, column in enumerate(FLAG_COLS)
        }
        feature_row["actual_rpm"] = float(rpm)
        frame = pd.DataFrame([feature_row], columns=[*FLAG_COLS, "actual_rpm"])
        transformed = self.rt_preprocessor.transform(frame)
        predicted_log_rt = float(self.rt_model.predict(transformed)[0])
        return float(np.expm1(predicted_log_rt))

    def candidate_rt(
        self,
        current_config: int,
        candidate_config: int,
        observed_rt95: float,
        rpm: float,
    ) -> float:
        # Same no-op rule as the offline DDQN and GA experiments.
        if int(candidate_config) == int(current_config):
            return float(observed_rt95)
        return self.predict_rt(candidate_config, rpm)

    def evaluate_candidate(
        self,
        current_config: int,
        candidate_config: int,
        observed_rt95: float,
        rpm: float,
    ) -> CandidateEvaluation:
        predicted_rt95 = self.candidate_rt(
            current_config=current_config,
            candidate_config=candidate_config,
            observed_rt95=observed_rt95,
            rpm=rpm,
        )
        changed_flags = self.config_space.changed_flags(current_config, candidate_config)
        distance = float(changed_flags / len(FLAG_COLS))
        normalized_rt = self.normalized_rt(predicted_rt95)
        violates = bool(predicted_rt95 > self.tau_ms)
        reward = -(self.alpha * distance + (1.0 - self.alpha) * normalized_rt)
        if violates:
            reward -= self.beta
        return CandidateEvaluation(
            config_id=int(candidate_config),
            reward=float(reward),
            predicted_rt95_ms=float(predicted_rt95),
            normalized_rt=float(normalized_rt),
            distance=float(distance),
            changed_flags=int(changed_flags),
            slo_compliant=bool(not violates),
        )

    def transform_to_valid(
        self,
        chromosome: np.ndarray,
        rng: random.Random,
    ) -> Tuple[np.ndarray, int, int]:
        chromosome = np.asarray(chromosome, dtype=int)
        key = tuple(chromosome.tolist())
        if key in self.tuple_to_index:
            index = int(self.tuple_to_index[key])
            return self.valid_x[index].copy(), index, 0

        distances = np.sum(self.valid_x != chromosome, axis=1)
        minimum = int(distances.min())
        candidate_indices = np.flatnonzero(distances == minimum).tolist()
        selected_index = int(rng.choice(candidate_indices))
        return self.valid_x[selected_index].copy(), selected_index, minimum


class DAGAMEGA:
    def __init__(self, problem: TransitionAwareGAProblem) -> None:
        self.problem = problem

    def choose_config(
        self,
        current_config: int,
        observed_rt95: float,
        rpm: float,
        seed: int,
    ) -> GASearchResult:
        rng = random.Random(int(seed))
        np_rng = np.random.default_rng(int(seed))
        evaluation_cache: Dict[int, CandidateEvaluation] = {}
        repair_distances: List[int] = []

        def evaluate(chromosome: np.ndarray) -> CandidateEvaluation:
            valid_vector, valid_index, _ = self.problem.transform_to_valid(chromosome, rng)
            config_id = int(self.problem.config_ids[valid_index])
            if config_id not in evaluation_cache:
                evaluation_cache[config_id] = self.problem.evaluate_candidate(
                    current_config=current_config,
                    candidate_config=config_id,
                    observed_rt95=observed_rt95,
                    rpm=rpm,
                )
            return evaluation_cache[config_id]

        def score(chromosome: np.ndarray) -> Tuple[float, float, float, int]:
            return evaluate(chromosome).rank_key

        started = perf_counter()
        population: List[np.ndarray] = []
        for _ in range(GA_POPULATION):
            raw = np_rng.integers(0, 2, size=self.problem.n_genes, dtype=int)
            valid, _, repair_distance = self.problem.transform_to_valid(raw, rng)
            population.append(valid)
            repair_distances.append(int(repair_distance))

        best_chromosome = max(population, key=score).copy()
        best_evaluation = evaluate(best_chromosome)

        for _ in range(GA_GENERATIONS):
            ranked = sorted(population, key=score, reverse=True)
            parent1 = ranked[0].copy()
            parent2 = ranked[1].copy()

            if rng.random() < GA_CROSSOVER_PROBABILITY:
                mask = np_rng.integers(0, 2, size=self.problem.n_genes, dtype=int)
                child = np.where(mask == 0, parent1, parent2).astype(int)
            else:
                child = parent1.copy()

            if rng.random() < GA_MUTATION_PROBABILITY:
                mutation_index = rng.randrange(self.problem.n_genes)
                child[mutation_index] = 1 - child[mutation_index]

            child, _, repair_distance = self.problem.transform_to_valid(child, rng)
            repair_distances.append(int(repair_distance))
            child_evaluation = evaluate(child)

            worst_position = min(
                range(len(population)),
                key=lambda index: score(population[index]),
            )
            if child_evaluation.rank_key > evaluate(population[worst_position]).rank_key:
                population[worst_position] = child

            if child_evaluation.rank_key > best_evaluation.rank_key:
                best_chromosome = child.copy()
                best_evaluation = child_evaluation

        selected = evaluate(best_chromosome)
        decision_time_ms = float((perf_counter() - started) * 1000.0)
        return GASearchResult(
            selected=selected,
            decision_time_ms=decision_time_ms,
            unique_evaluated_configs=int(len(evaluation_cache)),
            mean_repair_hamming=(
                float(np.mean(repair_distances)) if repair_distances else 0.0
            ),
            maximum_repair_hamming=(
                int(np.max(repair_distances)) if repair_distances else 0
            ),
        )


class GAPolicy:
    def __init__(self, metrics_df: pd.DataFrame, config_space: ConfigurationSpace) -> None:
        preprocessor = joblib.load(RT_PREPROCESSOR_PATH)
        rt_model = joblib.load(RT_MODEL_PATH)
        self.problem = TransitionAwareGAProblem(
            metrics_df=metrics_df,
            config_space=config_space,
            rt_preprocessor=preprocessor,
            rt_model=rt_model,
        )
        self.ga = DAGAMEGA(self.problem)

    def choose_config(
        self,
        current_config: int,
        observed_rt95: float,
        rpm: float,
        decision_index: int,
    ) -> Tuple[int, float, Dict[str, Any]]:
        decision_seed = int(GA_BASE_SEED + decision_index)
        result = self.ga.choose_config(
            current_config=current_config,
            observed_rt95=observed_rt95,
            rpm=rpm,
            seed=decision_seed,
        )
        return int(result.selected.config_id), float(result.decision_time_ms), {
            "ga_seed": decision_seed,
            "ga_predicted_rt95_ms": float(result.selected.predicted_rt95_ms),
            "ga_predicted_slo_compliant": bool(result.selected.slo_compliant),
            "ga_reward": float(result.selected.reward),
            "ga_unique_evaluated_configs": int(result.unique_evaluated_configs),
            "ga_mean_repair_hamming": float(result.mean_repair_hamming),
            "ga_maximum_repair_hamming": int(result.maximum_repair_hamming),
        }


# =============================================================================
# Kubernetes and k6 helpers
# =============================================================================


def load_service_config_map(path: Path) -> Dict[int, List[str]]:
    config_map: Dict[int, List[str]] = {}
    with path.open("r", newline="", encoding="utf-8") as handle:
        reader = csv.DictReader(handle)
        fields = set(reader.fieldnames or [])
        if not {"Config_ID", "Active_Services"}.issubset(fields):
            raise ValueError(
                f"Service configuration CSV must contain Config_ID and Active_Services. "
                f"Found: {reader.fieldnames}"
            )
        for row in reader:
            config_id = int(row["Config_ID"])
            raw = str(row["Active_Services"])
            services = [
                item.strip().lower()
                for item in raw.replace('"', "").split(",")
                if item.strip()
            ]
            config_map[config_id] = services
    return config_map


def kubectl_base_command() -> List[str]:
    command = ["kubectl"]
    if NAMESPACE.strip():
        command += ["-n", NAMESPACE.strip()]
    return command


def safe_scale_one(deployment: str, replicas: int) -> None:
    command = kubectl_base_command() + [
        "scale",
        "deployment",
        deployment,
        f"--replicas={int(replicas)}",
    ]
    result = subprocess.run(command, capture_output=True, text=True)
    if result.returncode == 0:
        return

    message = f"{result.stderr or ''}\n{result.stdout or ''}".strip()
    if "not found" in message.lower():
        logging.info("Deployment %s was not found; skipping it.", deployment)
        return
    raise RuntimeError(
        f"Failed to scale deployment {deployment} to {replicas}.\n{message}"
    )


def desired_services(
    config_id: int,
    service_config_map: Dict[int, List[str]],
    all_known_deployments: Set[str],
) -> Set[str]:
    if int(config_id) not in service_config_map:
        raise ValueError(f"Config {config_id} is missing from {SERVICE_CONFIG_CSV}.")
    needed = set(service_config_map[int(config_id)]) | set(ALWAYS_ON)
    return {service for service in needed if service in all_known_deployments}


def reconcile_start_config(
    config_id: int,
    service_config_map: Dict[int, List[str]],
    all_known_deployments: Set[str],
) -> Set[str]:
    """Force the cluster to the requested start configuration."""
    needed = desired_services(config_id, service_config_map, all_known_deployments)
    to_down = sorted(all_known_deployments - needed)
    to_up = sorted(needed)

    logging.info("Reconciling start Config %s", config_id)
    logging.info("Scale down: %s", to_down)
    logging.info("Scale up: %s", to_up)
    for deployment in to_down:
        safe_scale_one(deployment, 0)
    for deployment in to_up:
        safe_scale_one(deployment, 1)
    return needed


def apply_config_change(
    config_id: int,
    previous_needed: Set[str],
    service_config_map: Dict[int, List[str]],
    all_known_deployments: Set[str],
) -> Set[str]:
    needed = desired_services(config_id, service_config_map, all_known_deployments)
    to_down = sorted(previous_needed - needed)
    to_up = sorted(needed - previous_needed)

    logging.info("Applying Config %s", config_id)
    logging.info("Scale down: %s", to_down)
    logging.info("Scale up: %s", to_up)
    for deployment in to_down:
        safe_scale_one(deployment, 0)
    for deployment in to_up:
        safe_scale_one(deployment, 1)
    return needed


def run_k6_one_minute(
    output_dir: Path,
    config_id: int,
    target_rpm: float,
    minute_index: int,
    phase: str,
) -> Path:
    if output_dir.exists():
        shutil.rmtree(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    shell_command = (
        f"rm -rf {K6_OUTPUT_DIR_IN_POD} && mkdir -p {K6_OUTPUT_DIR_IN_POD} && "
        f"BASE_URL='{BASE_URL}' "
        f"CONFIG_ID='{int(config_id)}' "
        f"TARGET_RPM='{int(round(float(target_rpm)))}' "
        f"MINUTE_IDX='{int(minute_index)}' "
        f"PHASE='{str(phase)}' "
        f"OUT_DIR='{K6_OUTPUT_DIR_IN_POD}' "
        f"PRE_VUS='{PRE_VUS}' "
        f"MAX_VUS='{MAX_VUS}' "
        f"USER_ID_MIN='1' USER_ID_MAX='100' "
        f"k6 run {K6_SCRIPT_IN_POD}"
    )

    exec_command = kubectl_base_command() + [
        "exec",
        K6_POD,
        "--",
        "sh",
        "-lc",
        shell_command,
    ]
    console_log = output_dir / "k6_console.log"
    with console_log.open("w", encoding="utf-8") as handle:
        subprocess.run(
            exec_command,
            check=True,
            stdout=handle,
            stderr=handle,
            text=True,
        )

    pod_prefix = f"{K6_POD}:{K6_OUTPUT_DIR_IN_POD}/minute_stats.csv"
    local_csv = output_dir / "minute_stats.csv"
    copy_command = kubectl_base_command() + ["cp", pod_prefix, str(local_csv)]
    subprocess.run(
        copy_command,
        check=True,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        text=True,
    )

    if not local_csv.exists():
        raise FileNotFoundError(f"k6 output was not copied to {local_csv}")
    return local_csv


def read_minute_metrics(path: Path) -> Tuple[float, float, float]:
    frame = pd.read_csv(path)
    if frame.empty:
        raise ValueError(f"k6 minute output is empty: {path}")
    row = frame.iloc[0]

    def first_available(names: Sequence[str], default: Optional[float] = None) -> float:
        for name in names:
            if name in row.index and pd.notna(row[name]):
                return float(row[name])
        if default is not None:
            return float(default)
        raise ValueError(f"None of the expected columns {list(names)} exist in {path}")

    actual_rpm = first_available(("achieved_rpm", "actual_rpm", "rpm"), 0.0)
    failures = first_available(("failures", "http_req_failed", "failed_requests"), 0.0)
    rt95 = first_available(("rt_p95_ms", "rt_95", "rt95_ms", "p95_ms"))
    return actual_rpm, failures, rt95


# =============================================================================
# Online experiment execution
# =============================================================================


def build_policy(
    mode: str,
    config_space: ConfigurationSpace,
    metrics_df: pd.DataFrame,
) -> Any:
    if mode == "ddqn09":
        return DDQNPolicy(
            checkpoint_path=DDQN09_MODEL_PATH,
            expected_alpha=0.90,
            expected_seed=44,
            expected_sha256=DDQN09_MODEL_SHA256,
            config_space=config_space,
            metrics_df=metrics_df,
        )
    if mode == "ddqn0":
        return DDQNPolicy(
            checkpoint_path=DDQN0_MODEL_PATH,
            expected_alpha=0.00,
            expected_seed=45,
            expected_sha256=DDQN0_MODEL_SHA256,
            config_space=config_space,
            metrics_df=metrics_df,
        )
    if mode == "ga":
        return GAPolicy(metrics_df=metrics_df, config_space=config_space)
    return None


def select_policy_config(
    mode: str,
    policy: Any,
    current_config: int,
    observed_rt95: float,
    rpm: float,
    decision_index: int,
) -> Tuple[int, Optional[float], Dict[str, Any]]:
    if mode in {"ddqn09", "ddqn0"}:
        return policy.choose_config(current_config, observed_rt95, rpm)
    if mode == "ga":
        return policy.choose_config(current_config, observed_rt95, rpm, decision_index)
    if mode == "rule":
        started = perf_counter()
        selected = int(SAFE_CONFIG)
        elapsed_ms = float((perf_counter() - started) * 1000.0)
        return selected, elapsed_ms, {"rule_safe_config": int(SAFE_CONFIG)}
    raise ValueError(f"Policy selection is not applicable to mode {mode!r}.")


def close_active_event(
    active_event: Dict[str, Any],
    events: List[Dict[str, Any]],
    recovered: bool,
    status: str,
    recovery_minute: Optional[int] = None,
    recovery_rt95_ms: Optional[float] = None,
) -> None:
    if recovered:
        active_event["recovered"] = True
        active_event["event_status"] = status
        active_event["recovery_minute"] = int(recovery_minute) if recovery_minute is not None else None
        active_event["recovery_time_utc"] = utc_now_iso()
        active_event["recovery_rt95_ms"] = float(recovery_rt95_ms) if recovery_rt95_ms is not None else None
        active_event["e2e_adaptation_time_s"] = float(
            perf_counter() - float(active_event.pop("_trigger_perf_counter"))
        )
    else:
        active_event["recovered"] = False
        active_event["event_status"] = status
        active_event["recovery_minute"] = None
        active_event["recovery_time_utc"] = None
        active_event["recovery_rt95_ms"] = None
        active_event["e2e_adaptation_time_s"] = None
        active_event.pop("_trigger_perf_counter", None)
    events.append(active_event)


def summarize_run(
    mode: str,
    run_number: int,
    start_config: int,
    minute_logs: List[Dict[str, Any]],
    events: List[Dict[str, Any]],
) -> Dict[str, Any]:
    measured_rt = [float(row["rt95_ms"]) for row in minute_logs]
    violations = [bool(row["is_violation"]) for row in minute_logs]
    adaptive = mode != "static"

    successful_events = [event for event in events if bool(event.get("recovered", False))]
    switched_events = [event for event in events if bool(event.get("switch_enacted", False))]
    no_op_events = [event for event in events if bool(event.get("no_op", False))]
    decision_times = [
        float(event["decision_time_ms"])
        for event in events
        if event.get("decision_time_ms") is not None
    ]
    e2e_times = [
        float(event["e2e_adaptation_time_s"])
        for event in successful_events
        if event.get("e2e_adaptation_time_s") is not None
    ]

    trigger_count = len(events) if adaptive else 0
    recovery_rate = (
        float(100.0 * len(successful_events) / trigger_count)
        if adaptive and trigger_count > 0
        else None
    )

    return {
        "method": mode,
        "run": int(run_number),
        "start_config": int(start_config),
        "safe_config": int(SAFE_CONFIG) if mode == "rule" else None,
        "minutes": int(len(minute_logs)),
        "tau_ms": float(TAU_MS),
        "violation_intervals": int(sum(violations)),
        "violation_rate_pct": float(100.0 * mean(violations)) if violations else None,
        "mean_measured_rt95_ms": safe_mean(measured_rt),
        "median_measured_rt95_ms": safe_median(measured_rt),
        "maximum_measured_rt95_ms": max(measured_rt) if measured_rt else None,
        "trigger_count": int(trigger_count),
        "successful_recoveries": int(len(successful_events)) if adaptive else None,
        "failed_or_unresolved_recoveries": int(trigger_count - len(successful_events)) if adaptive else None,
        "recovery_rate_pct": recovery_rate,
        "mean_e2e_adaptation_time_s": safe_mean(e2e_times),
        "median_e2e_adaptation_time_s": safe_median(e2e_times),
        "switch_count": int(len(switched_events)) if adaptive else None,
        "no_op_count": int(len(no_op_events)) if adaptive else None,
        "mean_transition_distance_switches_only": safe_mean(
            [float(event["transition_distance"]) for event in switched_events]
        ),
        "mean_changed_flags_switches_only": safe_mean(
            [float(event["changed_flags"]) for event in switched_events]
        ),
        "mean_functionality_retention_switches_only": safe_mean(
            [float(event["functionality_retention"]) for event in switched_events]
        ),
        "mean_decision_time_ms": safe_mean(decision_times),
        "median_decision_time_ms": safe_median(decision_times),
        "p95_decision_time_ms": safe_p95(decision_times),
        "decision_time_is_supplementary": True,
    }


def run_one_repetition(
    mode: str,
    run_number: int,
    start_config: int,
    run_dir: Path,
    trace: pd.DataFrame,
    config_space: ConfigurationSpace,
    service_config_map: Dict[int, List[str]],
    all_known_deployments: Set[str],
    policy: Any,
    initial_wait_seconds: int,
) -> Dict[str, Any]:
    run_dir.mkdir(parents=True, exist_ok=False)
    log_path = run_dir / "controller.log"
    file_handler = logging.FileHandler(log_path, encoding="utf-8")
    logging.getLogger().addHandler(file_handler)

    minute_csv = run_dir / "online_results.csv"
    event_csv = run_dir / "adaptation_events.csv"
    summary_json = run_dir / "run_summary.json"

    minute_logs: List[Dict[str, Any]] = []
    completed_events: List[Dict[str, Any]] = []
    active_event: Optional[Dict[str, Any]] = None

    current_config = int(start_config)
    current_needed = reconcile_start_config(
        config_id=current_config,
        service_config_map=service_config_map,
        all_known_deployments=all_known_deployments,
    )
    logging.info(
        "Run %d/%s starts at Config %d after a %d-second preparation wait.",
        run_number,
        mode,
        current_config,
        initial_wait_seconds,
    )
    time.sleep(initial_wait_seconds)

    consecutive_violations = 0
    cooldown_remaining = 0
    decision_index = 0
    episode_index = 0

    try:
        for trace_position, trace_row in trace.iterrows():
            minute_index = int(trace_row.get("minute", trace_position + 1))
            target_rpm = float(trace_row["rpm"])
            phase = str(trace_row.get("phase", ""))
            config_used = int(current_config)

            minute_output_dir = run_dir / f"minute_{minute_index:03d}"
            measurement_start_utc = utc_now_iso()
            minute_stats_path = run_k6_one_minute(
                output_dir=minute_output_dir,
                config_id=config_used,
                target_rpm=target_rpm,
                minute_index=minute_index,
                phase=phase,
            )
            actual_rpm, failures, rt95 = read_minute_metrics(minute_stats_path)
            measurement_end_utc = utc_now_iso()
            is_violation = bool(rt95 > TAU_MS)

            # A previously triggered adaptation recovers at the first later compliant interval.
            recovery_closed_this_minute = False
            if active_event is not None and not is_violation:
                close_active_event(
                    active_event=active_event,
                    events=completed_events,
                    recovered=True,
                    status="recovered_first_compliant_post_trigger_interval",
                    recovery_minute=minute_index,
                    recovery_rt95_ms=rt95,
                )
                active_event = None
                recovery_closed_this_minute = True

            selected_config: Optional[int] = None
            decision_time_ms: Optional[float] = None
            decision_metadata: Dict[str, Any] = {}
            trigger = False
            switch_enacted = False
            changed_flags: Optional[int] = None
            transition_distance: Optional[float] = None
            functionality_retention: Optional[float] = None
            retained_optional_count: Optional[int] = None
            current_optional_count: Optional[int] = None
            selected_optional_count: Optional[int] = None

            if is_violation:
                if cooldown_remaining > 0:
                    cooldown_remaining -= 1
                    consecutive_violations = 0
                else:
                    consecutive_violations += 1
            else:
                consecutive_violations = 0
                if cooldown_remaining > 0:
                    cooldown_remaining -= 1

            if (
                mode != "static"
                and is_violation
                and cooldown_remaining == 0
                and consecutive_violations >= VIOLATION_PERSISTENCE
            ):
                trigger = True
                consecutive_violations = 0

                # A new adaptation supersedes any older attempt that has not recovered.
                if active_event is not None:
                    close_active_event(
                        active_event=active_event,
                        events=completed_events,
                        recovered=False,
                        status="superseded_by_new_adaptation_before_recovery",
                    )
                    active_event = None

                trigger_time_utc = utc_now_iso()
                trigger_perf_counter = perf_counter()
                selected_config, decision_time_ms, decision_metadata = select_policy_config(
                    mode=mode,
                    policy=policy,
                    current_config=current_config,
                    observed_rt95=rt95,
                    rpm=actual_rpm,
                    decision_index=decision_index,
                )
                decision_index += 1
                config_space.validate_id(selected_config)

                changed_flags = config_space.changed_flags(current_config, selected_config)
                transition_distance = config_space.normalized_distance(current_config, selected_config)
                (
                    functionality_retention,
                    retained_optional_count,
                    current_optional_count,
                    selected_optional_count,
                ) = config_space.functional_retention(current_config, selected_config)
                no_op = bool(selected_config == current_config)
                switch_enacted = bool(not no_op)

                episode_index += 1
                active_event = {
                    "episode_id": int(episode_index),
                    "method": mode,
                    "run": int(run_number),
                    "trigger_minute": int(minute_index),
                    "trigger_time_utc": trigger_time_utc,
                    "trigger_rt95_ms": float(rt95),
                    "trigger_actual_rpm": float(actual_rpm),
                    "initial_config": int(current_config),
                    "selected_config": int(selected_config),
                    "decision_time_ms": float(decision_time_ms),
                    "no_op": bool(no_op),
                    "switch_enacted": bool(switch_enacted),
                    "changed_flags": int(changed_flags),
                    "transition_distance": float(transition_distance),
                    "functionality_retention": float(functionality_retention),
                    "retained_optional_count": int(retained_optional_count),
                    "current_optional_enabled_count": int(current_optional_count),
                    "selected_optional_enabled_count": int(selected_optional_count),
                    "warmup_seconds": int(RECONFIGURATION_WARMUP_SECONDS if switch_enacted else 0),
                    "recovered": None,
                    "event_status": "awaiting_recovery",
                    "recovery_minute": None,
                    "recovery_time_utc": None,
                    "recovery_rt95_ms": None,
                    "e2e_adaptation_time_s": None,
                    "_trigger_perf_counter": trigger_perf_counter,
                    **decision_metadata,
                }

                if switch_enacted:
                    current_needed = apply_config_change(
                        config_id=selected_config,
                        previous_needed=current_needed,
                        service_config_map=service_config_map,
                        all_known_deployments=all_known_deployments,
                    )
                    current_config = int(selected_config)
                    cooldown_remaining = int(COOLDOWN_MINUTES)
                    time.sleep(RECONFIGURATION_WARMUP_SECONDS)

            minute_row: Dict[str, Any] = {
                "run": int(run_number),
                "method": mode,
                "minute": int(minute_index),
                "phase": phase,
                "measurement_start_utc": measurement_start_utc,
                "measurement_end_utc": measurement_end_utc,
                "target_rpm": float(target_rpm),
                "actual_rpm": float(actual_rpm),
                "failures": float(failures),
                "rt95_ms": float(rt95),
                "tau_ms": float(TAU_MS),
                "is_violation": bool(is_violation),
                "violation_persistence_count": int(consecutive_violations),
                "trigger": bool(trigger),
                "config_used": int(config_used),
                "selected_config": int(selected_config) if selected_config is not None else None,
                "config_after": int(current_config),
                "decision_time_ms": float(decision_time_ms) if decision_time_ms is not None else None,
                "switch_enacted": bool(switch_enacted),
                "changed_flags": int(changed_flags) if changed_flags is not None else None,
                "transition_distance": float(transition_distance) if transition_distance is not None else None,
                "functionality_retention": (
                    float(functionality_retention) if functionality_retention is not None else None
                ),
                "cooldown_remaining": int(cooldown_remaining),
                "active_episode_id": (
                    int(active_event["episode_id"]) if active_event is not None else None
                ),
                "recovery_closed_this_minute": bool(recovery_closed_this_minute),
                **decision_metadata,
            }
            minute_logs.append(minute_row)

            pd.DataFrame(minute_logs).to_csv(minute_csv, index=False)
            events_for_file = completed_events + ([active_event] if active_event is not None else [])
            clean_events = [
                {key: value for key, value in event.items() if not key.startswith("_")}
                for event in events_for_file
            ]
            pd.DataFrame(clean_events).to_csv(event_csv, index=False)

            logging.info(
                "[run=%d minute=%d] cfg=%d rt95=%.3f rpm=%.1f violation=%s "
                "trigger=%s selected=%s after=%d",
                run_number,
                minute_index,
                config_used,
                rt95,
                actual_rpm,
                is_violation,
                trigger,
                selected_config,
                current_config,
            )

        if active_event is not None:
            close_active_event(
                active_event=active_event,
                events=completed_events,
                recovered=False,
                status="trace_ended_before_recovery",
            )
            active_event = None

        pd.DataFrame(minute_logs).to_csv(minute_csv, index=False)
        pd.DataFrame(completed_events).to_csv(event_csv, index=False)
        summary = summarize_run(
            mode=mode,
            run_number=run_number,
            start_config=start_config,
            minute_logs=minute_logs,
            events=completed_events,
        )
        write_json(summary_json, summary)
        return summary

    except Exception as exc:
        logging.exception("Run %d failed: %s", run_number, exc)
        if active_event is not None:
            active_event.pop("_trigger_perf_counter", None)
            active_event["event_status"] = "controller_error"
            active_event["recovered"] = False
            completed_events.append(active_event)
        if minute_logs:
            pd.DataFrame(minute_logs).to_csv(minute_csv, index=False)
        if completed_events:
            pd.DataFrame(completed_events).to_csv(event_csv, index=False)
        write_json(
            run_dir / "run_error.json",
            {
                "method": mode,
                "run": run_number,
                "error_type": type(exc).__name__,
                "error": str(exc),
                "time_utc": utc_now_iso(),
            },
        )
        raise
    finally:
        logging.getLogger().removeHandler(file_handler)
        file_handler.close()


def aggregate_session_summaries(
    mode: str,
    start_config: int,
    session_dir: Path,
    summaries: List[Dict[str, Any]],
) -> None:
    summary_frame = pd.DataFrame(summaries)
    summary_frame.to_csv(session_dir / "all_run_summaries.csv", index=False)

    aggregate_metrics = [
        "violation_rate_pct",
        "mean_measured_rt95_ms",
        "recovery_rate_pct",
        "mean_e2e_adaptation_time_s",
        "mean_transition_distance_switches_only",
        "mean_functionality_retention_switches_only",
        "mean_decision_time_ms",
    ]
    aggregate: Dict[str, Any] = {
        "method": mode,
        "start_config": int(start_config),
        "runs_completed": int(len(summaries)),
        "aggregation_unit": "runtime repetition",
        "decision_time_is_supplementary": True,
    }
    for metric in aggregate_metrics:
        values = [
            float(item[metric])
            for item in summaries
            if item.get(metric) is not None and np.isfinite(float(item[metric]))
        ]
        aggregate[f"{metric}_mean"] = safe_mean(values)
        aggregate[f"{metric}_sample_sd"] = (
            float(np.std(values, ddof=1)) if len(values) >= 2 else None
        )
    write_json(session_dir / "aggregate_summary.json", aggregate)


def build_argument_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Run the unified JNN RQ3 online controller."
    )
    parser.add_argument(
        "--mode",
        required=True,
        choices=sorted(MODE_ALIASES.keys()),
        help="ddqn09, ddqn0, ga, rule, or static",
    )
    parser.add_argument(
        "--start-config",
        type=int,
        default=39,
        help="Starting Config_ID shared by all compared methods (default: 39).",
    )
    parser.add_argument(
        "--runs",
        type=int,
        default=3,
        help="Number of complete runtime repetitions (default: 3).",
    )
    return parser


def main() -> None:
    args = build_argument_parser().parse_args()
    mode = MODE_ALIASES[args.mode]
    start_config = int(args.start_config)
    runs = int(args.runs)
    if runs < 1:
        raise ValueError("--runs must be at least 1.")

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)s | %(message)s",
        handlers=[logging.StreamHandler()],
    )

    validate_required_paths(mode)
    config_space = ConfigurationSpace(BINARY_CONFIG_CSV)
    config_space.validate_id(start_config)
    config_space.validate_id(SAFE_CONFIG)

    metrics_df = pd.read_csv(METRICS_CSV)
    missing_metrics = [column for column in ("actual_rpm", "rt_95") if column not in metrics_df.columns]
    if missing_metrics:
        raise ValueError(f"Metrics CSV is missing columns: {missing_metrics}")

    trace = pd.read_csv(TRACE_CSV)
    if "rpm" not in trace.columns:
        raise ValueError(f"Trace CSV must contain an 'rpm' column: {TRACE_CSV}")
    if trace.empty:
        raise ValueError("Trace CSV is empty.")

    service_config_map = load_service_config_map(SERVICE_CONFIG_CSV)
    if start_config not in service_config_map:
        raise ValueError(f"Start config {start_config} is absent from {SERVICE_CONFIG_CSV}.")
    if SAFE_CONFIG not in service_config_map:
        raise ValueError(f"Safe config {SAFE_CONFIG} is absent from {SERVICE_CONFIG_CSV}.")

    all_known_deployments = set(ALWAYS_ON)
    for services in service_config_map.values():
        all_known_deployments.update(services)

    policy = build_policy(mode, config_space, metrics_df)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    session_dir = OUTPUT_ROOT / f"{mode}_start{start_config}_{timestamp}"
    session_dir.mkdir(parents=True, exist_ok=False)

    experiment_settings = {
        "method": mode,
        "start_config": start_config,
        "requested_runs": runs,
        "safe_config": SAFE_CONFIG,
        "tau_ms": TAU_MS,
        "violation_persistence": VIOLATION_PERSISTENCE,
        "cooldown_minutes": COOLDOWN_MINUTES,
        "reconfiguration_warmup_seconds": RECONFIGURATION_WARMUP_SECONDS,
        "between_runs_wait_seconds": BETWEEN_RUNS_WAIT_SECONDS,
        "trace_csv": TRACE_CSV,
        "service_config_csv": SERVICE_CONFIG_CSV,
        "binary_config_csv": BINARY_CONFIG_CSV,
        "metrics_csv": METRICS_CSV,
        "ddqn09_model": DDQN09_MODEL_PATH if mode == "ddqn09" else None,
        "ddqn0_model": DDQN0_MODEL_PATH if mode == "ddqn0" else None,
        "ga_settings": {
            "alpha": GA_ALPHA,
            "beta": GA_BETA,
            "population": GA_POPULATION,
            "generations": GA_GENERATIONS,
            "base_seed": GA_BASE_SEED,
            "decision_seed_rule": "GA_BASE_SEED + decision_index; sequence restarts every run",
        } if mode == "ga" else None,
        "main_metrics": [
            "violation_rate_pct",
            "mean_measured_rt95_ms",
            "recovery_rate_pct",
            "mean_e2e_adaptation_time_s",
            "mean_transition_distance_switches_only",
            "mean_functionality_retention_switches_only",
        ],
        "supplementary_metric": "decision_time_ms",
        "created_utc": utc_now_iso(),
    }
    write_json(session_dir / "experiment_settings.json", experiment_settings)

    summaries: List[Dict[str, Any]] = []
    for run_number in range(1, runs + 1):
        initial_wait = (
            RECONFIGURATION_WARMUP_SECONDS
            if run_number == 1
            else BETWEEN_RUNS_WAIT_SECONDS
        )
        run_dir = session_dir / f"run_{run_number}"
        summary = run_one_repetition(
            mode=mode,
            run_number=run_number,
            start_config=start_config,
            run_dir=run_dir,
            trace=trace,
            config_space=config_space,
            service_config_map=service_config_map,
            all_known_deployments=all_known_deployments,
            policy=policy,
            initial_wait_seconds=initial_wait,
        )
        summaries.append(summary)
        logging.info("Completed run %d/%d. Summary: %s", run_number, runs, summary)

    aggregate_session_summaries(
        mode=mode,
        start_config=start_config,
        session_dir=session_dir,
        summaries=summaries,
    )
    logging.info("All runs completed. Results saved to %s", session_dir)


if __name__ == "__main__":
    main()
